package com.carp.weixin.pojo.menu;

public class Button {
	private String name;  
	  
    public String getName() {  
        return name;  
    }  
  
    public void setName(String name) {  
        this.name = name;  
    }  
}
