package com.carp.weixin.pojo.menu;

public class Menu {
	private Button[] button;  
	  
    public Button[] getButton() {  
        return button;  
    }  
  
    public void setButton(Button[] button) {  
        this.button = button;  
    }  
}
