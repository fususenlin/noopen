package com.carp.weixin.test;

import com.carp.weixin.dao.TokenDao;
import com.carp.weixin.pojo.AccessToken;
import com.carp.weixin.util.WeixinUtil;

public class TokenTest {

	public static void main(String[] args) throws Exception {
		TokenDao tokenDao = new TokenDao();
		AccessToken at = tokenDao.get();
		System.out.println("yes!"+at.getToken());

	}

}
