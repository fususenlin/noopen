package com.carp.weixin.pojo.customerMessage;

public class CustomerArticles {
	private CustomerArticle[] articles;

	public CustomerArticle[] getArticles() {
		return articles;
	}

	public void setArticles(CustomerArticle[] articles) {
		this.articles = articles;
	}
	
}
